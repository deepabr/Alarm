/*
 *
 * Copyright (c) Microsoft. All rights reserved.
 * Licensed under the MIT license.
 *
 * Project Oxford: http://ProjectOxford.ai
 *
 * Project Oxford Mimicker Alarm Github:
 * https://github.com/Microsoft/ProjectOxford-Apps-MimickerAlarm
 *
 * Copyright (c) Microsoft Corporation
 * All rights reserved.
 *
 * MIT License:
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

package rosmi.acagild.alarmclock.appcore;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.MenuItem;



import java.util.ArrayList;
import java.util.UUID;

import rosmi.acagild.alarmclock.R;
import rosmi.acagild.alarmclock.model.Alarm;
import rosmi.acagild.alarmclock.onboarding.OnboardingToSFragment;
import rosmi.acagild.alarmclock.onboarding.OnboardingTutorialFragment;
import rosmi.acagild.alarmclock.scheduling.AlarmNotificationManager;
import rosmi.acagild.alarmclock.scheduling.AlarmScheduler;
import rosmi.acagild.alarmclock.settings.AlarmSettingsFragment;
import rosmi.acagild.alarmclock.settings.MimicsSettingsFragment;
import rosmi.acagild.alarmclock.utilities.GeneralUtilities;
import rosmi.acagild.alarmclock.utilities.Loggable;
import rosmi.acagild.alarmclock.utilities.Logger;
import rosmi.acagild.alarmclock.utilities.SettingsUtilities;

/**
 * The AlarmMainActivity is the launch activity for the application.  It has the following
 * features:
 *
 *      On launch it is determined whether the onboarding/tutorial experience has been completed. If
 *      not, the user is presented with the tutorial. On completion the user does not see the
 *      tutorial again unless it is accessed from the options menu.
 *
 *      After the tutorial is completed, the user is presented with the consent ux with the terms of
 *      service.  The user will not be able to use the application until the terms of service have
 *      been accepted.
 *
 *      Once the terms of service have been accepted, the alarm list will be shown (AlarmListFragment)
 *      on first run and subsequent launches of the application.
 *
 *      Once the user adds or selects an alarm, the activity will transition from the alarm list to
 *      the alarm settings page (AlarmSettingsFragment).  From there, the user can transition
 *      further to the Mimics settings page (MimicsSettingsFragment).
 *
 *      If the user selects any options on the Options menu - Settings (AlarmGlobalSettingsActivity)
 *      , Tutorial, Learn more (LearnMoreActivity) this activity will schedule the transitions to
 *      those screens.
 *
 *      This activity can be started (onCreate) or restarted (onIntent) with an alarm id argument,
 *      to enable launches to a specific alarm settings page.
 *
 *      This activity overrides the back button to better handle the specific transitions
 *      between the different settings pages etc.
 *
 *      This activity listens for volume key presses and updates the alarm volume state while
 *      displaying the system volume ui.
 *
 * The different fragments that are launched from this activity communicate their status back
 * to the activity via listener interfaces.
 */
public class AlarmMainActivity extends AppCompatActivity
        implements AlarmListFragment.AlarmListListener,
        OnboardingTutorialFragment.OnOnboardingTutorialListener,
        OnboardingToSFragment.OnOnboardingToSListener,
        AlarmSettingsFragment.AlarmSettingsListener,
        MimicsSettingsFragment.MimicsSettingsListener {

    public final static String SHOULD_ONBOARD = "onboarding";
    public final static String SHOULD_TOS = "show-tos";
    private SharedPreferences mPreferences = null;
    private AudioManager mAudioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);
        String packageName = getApplicationContext().getPackageName();
        mPreferences = getSharedPreferences(packageName, MODE_PRIVATE);
        PreferenceManager.setDefaultValues(this, R.xml.pref_global, false);
        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        AlarmNotificationManager.get(this).handleNextAlarmNotificationStatus();

        UUID alarmId = (UUID) getIntent().getSerializableExtra(AlarmScheduler.ARGS_ALARM_ID);
        if (alarmId != null) {
            showAlarmSettingsFragment(alarmId.toString());
        }

        Logger.init(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        UUID alarmId = (UUID) intent.getSerializableExtra(AlarmScheduler.ARGS_ALARM_ID);
        if (alarmId != null) {
            showAlarmSettingsFragment(alarmId.toString());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();


        if (mPreferences.getBoolean(SHOULD_ONBOARD, true)) {
            if (!hasOnboardingStarted()) {
                Loggable.UserAction userAction = new Loggable.UserAction(Loggable.Key.ACTION_ONBOARDING);
                Logger.track(userAction);

                showTutorial(null);
            }
        }
        else if (mPreferences.getBoolean(SHOULD_TOS, true)) {
            showToS();
        } else if (!SettingsUtilities.areEditingSettings(getSupportFragmentManager())) {
            GeneralUtilities.showFragment(getSupportFragmentManager(),
                    new AlarmListFragment(),
                    AlarmListFragment.ALARM_LIST_FRAGMENT_TAG);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //FeedbackManager.unregister();
        Logger.flush();
    }

    //
    // Launch User Voice forum form to allow user feedback submission
    //
    public void showUserVoiceFeedback(MenuItem item) {
        /*UserVoice.launchUserVoice(this);*/
    }

    public void showTutorial(MenuItem item){
        if (item != null) {
            GeneralUtilities.showFragmentFromLeft(getSupportFragmentManager(),
                    new OnboardingTutorialFragment(),
                    OnboardingTutorialFragment.ONBOARDING_FRAGMENT_TAG);
        } else {
            GeneralUtilities.showFragment(getSupportFragmentManager(),
                    new OnboardingTutorialFragment(),
                    OnboardingTutorialFragment.ONBOARDING_FRAGMENT_TAG);
        }
    }

    @Override
    public void onSkip() {
        if (mPreferences.getBoolean(SHOULD_TOS, true)) {
            Loggable.UserAction userAction = new Loggable.UserAction(Loggable.Key.ACTION_ONBOARDING_SKIP);
            Logger.track(userAction);
            showToS();
        }
        else {
            GeneralUtilities.showFragmentFromRight(getSupportFragmentManager(),
                    new AlarmListFragment(),
                    AlarmListFragment.ALARM_LIST_FRAGMENT_TAG);
        }
    }

    @Override
    public void onAccept() {
        GeneralUtilities.showFragmentFromRight(getSupportFragmentManager(),
                new AlarmListFragment(),
                AlarmListFragment.ALARM_LIST_FRAGMENT_TAG);
    }

    @Override
    public void onBackPressed() {
        if (SettingsUtilities.areEditingAlarmSettingsExclusive(getSupportFragmentManager())) {
            SettingsUtilities.getAlarmSettingsFragment(getSupportFragmentManager()).onCancel();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            mAudioManager.adjustStreamVolume(AudioManager.STREAM_ALARM,
                    AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI | AudioManager.FLAG_PLAY_SOUND);
        } else if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            mAudioManager.adjustStreamVolume(AudioManager.STREAM_ALARM,
                    AudioManager.ADJUST_RAISE,
                    AudioManager.FLAG_SHOW_UI | AudioManager.FLAG_PLAY_SOUND);
        } else {
            return super.onKeyDown(keyCode, event);
        }
        return true;
    }

    public void showToS() {
        mPreferences.edit().putBoolean(SHOULD_ONBOARD, false).apply();
        GeneralUtilities.showFragment(getSupportFragmentManager(),
                new OnboardingToSFragment(),
                OnboardingToSFragment.TOS_FRAGMENT_TAG);
    }

    private boolean hasOnboardingStarted() {
        return (getSupportFragmentManager()
                .findFragmentByTag(OnboardingTutorialFragment.ONBOARDING_FRAGMENT_TAG) != null);
    }

    @Override
    public void onSettingsSaveOrIgnoreChanges() {
        GeneralUtilities.showFragmentFromLeft(getSupportFragmentManager(),
                new AlarmListFragment(),
                AlarmListFragment.ALARM_LIST_FRAGMENT_TAG);
        onAlarmChanged();
    }

    @Override
    public void onSettingsDeleteOrNewCancel() {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(android.R.anim.fade_in, R.anim.slide_down);
        transaction.replace(R.id.fragment_container, new AlarmListFragment());
        transaction.commit();
        onAlarmChanged();
    }

    @Override
    public void onMimicsSettingsDismiss(ArrayList<String> enabledMimics) {
        AlarmSettingsFragment settingsFragment = SettingsUtilities.
                getAlarmSettingsFragment(getSupportFragmentManager());
        if (settingsFragment != null){
            settingsFragment.updateMimicsPreference(enabledMimics);
        }
    }


    @Override
    public void onAlarmSelected(Alarm alarm) {
        showAlarmSettingsFragment(alarm.getId().toString());
    }

    @Override
    public void onAlarmChanged() {
        AlarmNotificationManager.get(this).handleNextAlarmNotificationStatus();
    }

    private void showAlarmSettingsFragment(String alarmId) {
        SettingsUtilities.transitionFromAlarmListToSettings(getSupportFragmentManager(), alarmId);
    }
}
